Hinweis: Bitte unter /sparql-converter die Datei "converter.exe" ausführen, um das Programm ohne Python zu nutzen.

Hierzu müssen ALLE restlichen Dateien in dem Ordner heruntergeladen werden und sich im selben Ordner wie die .exe-Datei befinden!
